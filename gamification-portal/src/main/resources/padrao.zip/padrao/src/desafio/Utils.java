package desafio;

import java.util.Arrays;
import java.util.Scanner;

public abstract class Utils {

	private static Scanner scannerEntrada;
	private static Scanner scannerSaida;
	
	private static Integer validacoes = 0;
	
	static {
		scannerEntrada = new Scanner("input.txt");
		scannerSaida = new Scanner("output.txt");
	}
	
	public static String getProximoCaracter() {
		return scannerEntrada.next();
	}
	
	public static Integer getProximoCaracterInteiro() {
		return Integer.valueOf(getProximoCaracter());
	}
	
	public static void validarSaida(Object object) {
		validacoes++;
		String valor = object.toString();
		if (!valor.equals(scannerSaida.next())) {
			throw new IllegalStateException("Valor resultante incorreto.");
		}
	}
	
	
	
}
