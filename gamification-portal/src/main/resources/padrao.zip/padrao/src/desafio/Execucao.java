package desafio;

public class Execucao {

	public void processarEntrada() {
		
		/**
		 * Implementar
		 */
		
	}
	
}
